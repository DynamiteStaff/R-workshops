# Welcome to Florence Summer School !!

# This 3h tutorial aims at : 
# Getting started with R and R studio
# Handle data frames
# Get to know so classical packages for data analysis
# Handle spatial data

# -----------------------------------------------------------
# Outline
# -----------------------------------------------------------
# 1. Short introduction to R 
# 1.1. R and R studio
# 1.2. R objects
# 1.3. special focus on data frames
# -----------------------------------------------------------
# 2. Data handling 
# 2.1. using specific packages
# 2.2. plots with R
# 2.3. statistics with R
# 2.4. spatial data with R
# -----------------------------------------------------------


# Some references



# A (very) short introduction to R Paul Torfs & Claudia Brauer
# https://cran.r-project.org/doc/contrib/Torfs+Brauer-Short-R-Intro.pdf


# see https://framabook.org/r-et-espace/ (in French) to a broader introduction
# points towards
# WICKHAM H. (2014), Advanced R, http://adv-r.had.co.nz/

# comprehensive blog on tidyverse (ggplot2, dplyr, sf)
# https://www.tidyverse.org/










# -----------------------------------------------------------
# 1. Short introduction to R 

# -----------------------------------------------------------
# 1.1. R and R studio

# 1.1.1. Discovering R studio interface


# type 1+1 on the below left screen (the console)
1+1 #Ctrl + Enter or "Run"
#create a script (use File / New File / R script )
#other type of scripts are available
# R + markdown 
# R + LateX (Sweave)
# R + Shiny
# etc etc.

help()
help(base) #help on a package (here R-base)
help(sum)
#or
?sum #help on a function

# Working directory to handle
setwd("C:/Users/florent.le-nechet/Desktop/R_tuto")
getwd() # see where is current working directory

# 1.1.2. Getting started with R

#Get to know the syntax

a <- 1 #Allocation
a = 2 #Also allocation 
######## might be aconfusing syntax - try to avoid)
######## note that it updated the value of a (top right corner of R studio)

a == 1 #Test
2 * a -> b #Another allocation (rare)
# R is case sensitive
B

# We just saw a first kind of objects : numeric (num)
str(b)

# Let's see another : character (chr)
c <- "Hello world"
str(c)
# You will encounter many kind of objects during this week. 
# You will update objects, merge objects, use objects in procedures, visualize objects, etc.
# One common source of mistake for beginners : 
b+1
# does not affect value of b
b <- b+1 #does
# R console do not display the result : nevertheless it worked
b


# 1.1.3. Packages in R
# Some basic fonctions can be used
substr(c,1,5) #function that select successive characters from position 1 to 5
paste(c,c, sep = ";") #function that concatenates characters

# the list of R-base function is however limited (only 1230 functions ;o)

# You can implement your own functions
squared <- function (x) {
  x * x
}
str(squared)
squared(3) + squared(4)

# But the R community did a lot already! Packages are collections of functions
# In 2014, 50 00 packages on CRAN, as of 2018, 13 000 packages on CRAN
# use install.packages to download a package from CRAN,
# use library("name of package") to load it in the current R session
# see below for examples

# -----------------------------------------------------------
# 1.2. R objects

# 1.2.1. Vectors
#Vector
d <- c(10, 5, 0) #Create a vector of numeric values
d #Show the content of d
str(d)
d[1] # aelect only the first element of the vector
2:40 # another way to declare vectors (pretty compact)
2:40 * 10 # and how to play with it

1:3 + d # operations are possible on vectors of same size 
1:30 + d # but also if sizes are different : use with caution to avoid misuse

# tests with vectors
1:10 == 2
1:10 %in% d

e <- c("R","is","a","pretty","good","platform","for","data","analysis")
str(e)
e[c(5,8)] #Very commonly used way to select parts of vectors
e[1:6]
length(e)
e[1:length(e) %in% d]
ls() #List of stored objects
# 1.2.2. Lists
#Lists
#You can not easily mix num and chr classes
d + e
paste(d,e)

#But you can create lists with heterogeneous class
f <- list(d,e)
str(f)
f[1]
f[2]
f <- append(f, c)
f
# 1.2.3. Change objects class in R

is.character(d)
d <- as.character(d)
is.character(d)
d
#but not always a good option
is.numeric(d)
is.numeric(e)
as.numeric(d)
as.numeric(e)


rm("a") 
rm(list = ls())

# -----------------------------------------------------------
# 1.3. special focus on data frames
#one of the most commun objects class for data analysis

g <- matrix(c(1,3,2,4), 2, 2)
g
h <- data.frame(g)
str(h)
names(h)
names(h) <- c("columnA", "columnB")
h$columnA
sum(h$columnB)

k <- data.frame(matrix(c(1,3,5,33,NA,24), 3, 2))
names(k) <- c("columnA","columnB")
# combine h and k data frames
h
k
rbind(h,k) #bind horizontally
cbind(h,k) #bind vertically
merge(x = h,y = k,by = "columnA") #join tables x and y via a common identifier
hk <- merge(h,k,by = "columnA", all.y = TRUE) #keep all values from y table
sum(hk$columnB.y)
sum(hk$columnB.y, na.rm = T)

hk[1,2]
# remove rows with at least one NA
na.omit(hk)

# also a useful method to replace all NA values in a table (use with caution)
hk[is.na(hk)] <- 0
hk

# 1.3.2. Import / Export data frames

ph <- read.csv("base-cc-serie-historique_pop_logement.csv", sep=";")
str(ph)

head(ph$CODGEO)
# some CODGEO have four digit instead of five (the initial 0 disappeared due to external treatment)
table(ph$CODGEO >= 10000)
# here's a classic patch to handle this
conditionA <- ph$CODGEO < 10000
table(conditionA)
ph$INSEE_COM <- as.character(ph$CODGEO) 
ph$INSEE_COM[conditionA] <- paste("0",as.character(ph$CODGEO[conditionA]), sep = "")
head(ph$INSEE_COM)

summary(ph)
sum(ph$P13_POP)

sum(ph$D68_POP)
#export data frame with function write.table (see below)

# 1.3.3. Handle data frames

names(ph)

# create departement discrict identifier
ph$INSEE_DEP <- substr(ph$INSEE_COM,1,2)
# select only communes that lies in the "Ile-de-France" region
# dep = 75, 77, 78, 91, 92, 93, 94, 95
vect_departement_IdF <- c("75", "77", "78", "91", "92", "93", "94", "95")
conditionB <- ph$INSEE_DEP %in% vect_departement_IdF

str(conditionB)
table(conditionB) #Pilot table

ph_IdF <- subset(ph, conditionB)
ph_IdF_other_method <- ph[conditionB,]
rm(ph_IdF_other_method)
#select only columns of interest
names(ph_IdF)
ph_IdF_2013 <- subset(ph_IdF, select = c("INSEE_COM","INSEE_DEP","P13_POP","P13_LOG","P13_LOGVAC"))
ph_IdF_2013_other_method <- ph_IdF[,c(3,11,18,25,26)]
#Click on data frames to see the differences (top right screen)
rm(ph_IdF_2013_other_method)

#Factor
# Here we get to know the factor class 
# We will easily aggregate data using the following geographical classification
# 75 is Paris departement : it is "Paris city center" = CEN
# 92, 93 and 94 are "Paris inner ring" = RIN
# 77, 78, 91, 95 are "Paris outer ring" = ROUT
table(ph_IdF_2013$INSEE_DEP)
#popDep <- aggregate(popCom3608[ , c("POP1936", "POP2008")],
  #                  by = list(popCom3608$DEP),
 #                   FUN = sum)
#tapply()
nrow(ph_IdF_2013)
ncol(ph_IdF_2013)
length(ph_IdF_2013$P13_POP)

ph_IdF_2013$INSEE_DEP_F <- factor(ph_IdF_2013$INSEE_DEP, labels  = c("1-CEN","3-OUT","3-OUT","3-OUT","2-IN","2-IN","2-IN","3-OUT"))
table(ph_IdF_2013$INSEE_DEP_F)

ph_IdF_2013_agg <- aggregate(ph_IdF_2013[,c("P13_POP","P13_LOG","P13_LOGVAC")], 
                                by = list(ph_IdF_2013$INSEE_DEP_F), 
                                FUN = "sum")
names(ph_IdF_2013_agg) <- c("RING","P13_POP", "P13_LOG","P13_LOGVAC")
ph_IdF_2013_agg


# Export data frame in csv format
write.table(ph_IdF_2013_agg, "ph_agg_per_ring.csv" , sep = ",", row.names = F)



# -----------------------------------------------------------
# 2. Data handling 
# -----------------------------------------------------------
# 2.1. using specific packages

library(sqldf)#"INSEE_COM","INSEE_DEP","P13_POP","P13_LOG","P13_LOGVAC"
ph_other <- sqldf("select P13_POP, INSEE_COM
                   from ph
                   where INSEE_DEP in (75,77,78,91,92,93,94,95)")
                         
#and other sql syntax you might be familiar with

#also packages exists that facilitate integration with C++, python, netlogo, etc.
  
                           
library("dplyr")

ph_tbl <- tbl_df(ph)

LOGVACpc_13_DEP <- ph_tbl %>%
  group_by(INSEE_DEP) %>%
  mutate(LOGVACpc = P13_LOGVAC / P13_LOG) %>%
  summarise(LOGVACpc = weighted.mean(LOGVACpc, P13_LOG))

library("reshape2")
names(ph_IdF)
ph_melt <- melt(ph_IdF[,c(3:9,25)],
     id.vars = c("INSEE_COM"),
     variable.name = "POP")

pop_communes <- dcast(ph_melt, POP ~ INSEE_COM)
pop_communes[,1:10]
plot(pop_communes$`75101`)

# -----------------------------------------------------------
# 2.2. plots with R
# 2.2.1. first plot with R

# we just obtained a poor graph
# X axis is lacking
pop_communes$year <- c(2013,2008,1999,1990, 1982, 1975, 1968)
plot(pop_communes$`75101`~pop_communes$year)
plot(pop_communes$`75101`~pop_communes$year, type = "l", col = "grey")
plot(pop_communes$`75101`~pop_communes$year, type = "l", col = "grey",
     xlab = "year",
     ylab = "population",
     main = "Population of communes from 1968 to 2013")
plot(pop_communes$`75101`~pop_communes$year, type = "l", col = "grey",
     xlab = "year",
     ylab = "population",
     main = "Population of communes from 1968 to 2013", 
     ylim = c(0,250000))

lines(pop_communes$year,pop_communes[,3], col = "grey", type = "l" )
for(i in c(4:1301)) {
lines(pop_communes$year,pop_communes[,i], col = "grey", type = "l" )
}
#it would be possible to adjust the color to the trajectory hence growing population, decreasing population, other
#see clustering techniques with R (package cluster for instance)

hist(LOGVACpc_13_DEP$LOGVACpc, 
     main = "% of vacant housing per departement, 2013",
     xlab = "%", ylab = "number of departements")

hist(LOGVACpc_13_DEP$LOGVACpc, 
     main = "% of vacant housing per departement, 2013",
     xlab = "%", ylab = "number of departements",
     breaks = 0:28/200, col = "magenta")
#we can then go back to the outliers if further exploration is needed


# -----------------------------------------------------------
# 2.3. statistics with R
# we will use another table (PAMM stands for Paris Marne Meaux, eastern part of Ile-de-France region)
# you shall find "communes_PAMM.csv" file (not recommanded in scripts)
communes_PAMM <- read.table(file.choose(), sep = ";", dec = ",", "header" = TRUE)

# 2.3.1. univariate statistics
names(communes_PAMM)

communes_PAMM <- merge(communes_PAMM, ph_IdF, by = "INSEE_COM")
hist(communes_PAMM$dParis)
# create a new variable : categories of distances
communes_PAMM$dParis_cat <- cut(communes_PAMM$dParis, breaks = c(0:5 * 10))
table(communes_PAMM$dParis_cat)
table(communes_PAMM$INSEE_DEP,communes_PAMM$dParis_cat)

# 2.3.2. linear regression


#Linear regression CHANGE PLACE VIA ANOTHER IMPORT THROUGH CSV FILE
names(communes_PAMM)

communes_PAMM$density13 <- with(communes_PAMM, P13_POP / AREA.HA)
plot(with(communes_PAMM, log(density13)~dParis), pch = 19, col = "light blue")
lm13 <- lm(with(communes_PAMM, log(density13)~dParis))
summary(lm13)
abline(lm13, col = "red")
plot(lm13)

communes_PAMM$density68 <- with(communes_PAMM, D68_POP / AREA.HA)
plot(with(communes_PAMM, log(density68)~dParis ), pch = 19, col = "light blue")



lm68 <- lm(with(communes_PAMM, log(density68)~dParis))
summary(lm68)
abline(lm68, col = "red")


# 2.3.3. Export residual data
# what do we learn from the linear regressions?
str(lm68)
# we rely on Clark law for density in monocentric city

summary(lm68)$r.squared
summary(lm13)$r.squared
# the quality of the model have not changed dramatically over time

lm68$coefficients
lm13$coefficients
# slope decreased over time, consistent with urban sprawl


communes_PAMM <- cbind(communes_PAMM, lm13$residuals)
# we store the residuals in order to map them

# -----------------------------------------------------------
# 2.4. Spatial data with R 

# -----------------------------------------------------------
# 2.4.1. Importing shapefile using sp + rgeos + rgdal

# This exemple comes from the R manual "R et espace", aforementioned
# It is extensively treated there
library("sp")
library("rgdal")
library("rgeos")
library("raster")
muniBound <- readOGR(dsn = "parispc_com.shp", layer = "parispc_com", encoding = "utf8", stringsAsFactors = FALSE)
class(muniBound)
str(muniBound)
plot(muniBound, col = "grey", border = "white", axes = TRUE)
muniBound <- spTransform(x = muniBound,
                        CRSobj = CRS("+init=epsg:2154"))

densGrid <- readGDAL("paris_dens.tif")
class(densGrid)
str(densGrid)
plot(densGrid)
# 2.4.2 Importing shapefile using sf package

# Explore sf file
library("sf")
library("ggplot2")

communes_PAMM_map <- read_sf("Communes.shp")
class(communes_PAMM_map)


# 2.4.3. Chloroplet map
ggplot(communes_PAMM_map) + geom_sf()

# handle vector class to allow join
communes_PAMM$INSEE_COM <- as.character(communes_PAMM$INSEE_COM)
communes_PAMM_map <- inner_join(communes_PAMM_map, communes_PAMM, by = "INSEE_COM")
ggplot(communes_PAMM_map) + geom_sf(aes(fill = communes_PAMM_map$density13))

ggplot(communes_PAMM_map) + geom_sf(aes(fill = communes_PAMM_map$density13)) + scale_fill_gradient(low = "white", high = "red")

ggplot(communes_PAMM_map) + geom_sf(aes(fill = communes_PAMM_map$`lm13$residuals`)) + scale_fill_gradient(low = "green", high = "blue")


str(communes_PAMM_map)
str(communes_PAMM_map$geometry)
length(communes_PAMM_map$geometry[])
communes_PAMM_map$geometry[[1]] #geometry of the first polygon

communes_PAMM_map_nospatial <- as.data.frame(communes_PAMM_map) #remove geometry
class(communes_PAMM_map_nospatial)


# 2.4.4. Points and buffers
stations_PAMM_map <- read_sf("emplacement-des-gares_corridor1km.shp")
plot(stations_PAMM_map["mode"], pch  = 19)

stations_buffer <- st_buffer(stations_PAMM_map, 1000)
plot(stations_buffer["mode"])


write_sf(stations_buffer, "stations_buffer.shp") # silently overwrites


# https://r-spatial.github.io/sf/articles/sf1.html to go further on sf geographical objects

# 2.4.5 create interactive maps
library("tmap")
library("tmaptools")
tm_shape(stations_buffer) + tm_polygons("mode",id = "nom_gare")
tmap_mode("view")
tmap_last()




# -----------------------------------------------------------

# Have a nice week @ Florence Summer School 2018, Labex Dynamite
# Florent Le N�chet, LVMT, Paris-Est University, Urban Futures LabeX
# September 2018

